# @bxbx/go-otp-framework

A lightweight Node.js/TypeScript adapter for the Go OTP Framework.

## Overview

This package acts as a thin HTTP transport layer around the existing Go OTP Framework backend. It contains no duplicated business logic. The Go backend remains the single source of truth for all Twilio, AWS SNS, Redis, and Mongo integrations.

## Installation

```bash
npm install @bxbx/go-otp-framework
```

## Usage

```typescript
import { OTPClient } from "@bxbx/go-otp-framework";

const otp = new OTPClient({
  baseURL: "http://localhost:8080",
  apiKey: "api_live_xxx" // Your programmatic API key
});

async function run() {
  // Check health
  const healthStatus = await otp.health();
  console.log("Health:", healthStatus);

  // Send an OTP
  await otp.sendOTP("+919876543210");
  console.log("OTP Sent!");

  // Verify an OTP
  const result = await otp.verifyOTP("+919876543210", "123456");
  console.log("Verified:", result);
}

run();
```

## API Reference

- `sendOTP(phone: string): Promise<any>`
- `verifyOTP(phone: string, otp: string): Promise<any>`
- `createAPIKey(userId: string): Promise<any>`
- `health(): Promise<any>`
